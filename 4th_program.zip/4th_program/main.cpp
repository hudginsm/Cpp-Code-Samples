#include <iostream>
#include <string>
using namespace std;
class MarcusClass
{
public:
    MarcusClass(string z)
    {
        setName(z);
    }
    void setName(string x)
    {
      name = x;
    }
    string getName()
    {
        return name;
    }
private:

        string name;

};
int main()
{
   MarcusClass Mo("Lucky Marcus");
   cout << Mo.getName();
    return 0;
}
