#include <iostream>
using namespace std;

void printSomething ();

int main()
{
    printSomething ();
    return 0;
}

void printSomething ()
{
    cout << "ooooo i am text on the screen" << endl;

}
