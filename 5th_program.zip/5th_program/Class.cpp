#include "Class.h"
#include <iostream>
using namespace std;

Class::Class()
{
    cout << "i am a bananna" << endl;
}
