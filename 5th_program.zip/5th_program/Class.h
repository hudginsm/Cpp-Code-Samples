#ifndef CLASS_H
#define CLASS_H


class Class
{
    public:
        Class();


};

#endif // CLASS_H
