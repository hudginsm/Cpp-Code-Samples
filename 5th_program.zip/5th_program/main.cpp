#include <iostream>
#include "Class.h"
using namespace std;

int main()
{
    Class mo;
    return 0;
}
