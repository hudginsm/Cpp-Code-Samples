#include <iostream>

using namespace std;
void passByValue(int x);
void passByReferance(int *x);
int main()
{
    int betty = 13;
    int sandy = 13;

    passByValue(betty);
    passByReferance(&sandy);
    cout << betty << endl;
    cout << sandy << endl;
}

void passByValue(int x)
{
    x = 99;
}

void passByReferance(int *x)
{
    *x = 66;
}
