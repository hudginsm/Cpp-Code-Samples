#ifndef DAUGHTER_H
#define DAUGHTER_H


class Daughter: public Mother
{
    public:
        Daughter();
        ~Daughter();
};

#endif // DAUGHTER_H
