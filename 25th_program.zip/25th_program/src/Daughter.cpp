#include <iostream>
#include "Mother.h"
#include "Daughter.h"
using namespace std;

Daughter::Daughter()
{
  cout << "Daughter con." << endl;
}

Daughter::~Daughter()
{
    cout << "Daughter decon." << endl;
}
