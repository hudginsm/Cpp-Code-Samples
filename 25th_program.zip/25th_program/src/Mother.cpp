#include <iostream>
#include "Mother.h"
#include "Daughter.h"
using namespace std;

Mother::Mother()
{
    cout << "i am the mother con." << endl;
}

Mother::~Mother()
{
    cout << "I am the mother decon." << endl;
}
