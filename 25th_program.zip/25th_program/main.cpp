#include <iostream>
#include "Mother.h"
#include "Daughter.h"
using namespace std;

int main()
{
  Daughter dina;
}
