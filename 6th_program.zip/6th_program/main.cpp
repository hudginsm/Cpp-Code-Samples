#include <iostream>
using namespace std;

int main()
{
    int x;

    cout << "what is you age" << endl;
    cin >> x;

    if(x>60)
    {
        if(x>100)
        {
           cout << "why are you still alive" << endl;
        }
        else
        {
           cout << "wow your old." << endl;
        }
    }
    else
    {
        cout << "you are young, get a job" << endl;
    }

    return 0;
}
