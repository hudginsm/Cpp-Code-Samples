#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

void Random();
void User();

int main()
{
    User();
    cout<< endl;
    Random();
    return 0;
}

void Random(){
    int ArryOfNumbers[6];
    srand(7);

    for(int AN= 0; AN<6; AN++)
    {
        ArryOfNumbers[AN]= 1+(rand()%6);
    }

    for(int PO=0; PO<6; PO++)
    {
        cout<< ArryOfNumbers[PO] << endl;
    }
}

void User(){
    int UsersNumbers[6];

     for (int UN=0; UN<6; UN++)
    {
        cout<< "please enter a number between 1-6: " <<endl;
        cin>> UsersNumbers[UN];
    }

    cout << endl;

    for(int PO=0; PO<6; PO++)
    {
        cout<< UsersNumbers[PO] <<endl;
    }
}

