#ifndef SALLY_H
#define SALLY_H


class Sally
{
    public:
        int num;
        Sally();
        Sally(int);
        Sally operator+(Sally);
};

#endif // SALLY_H
