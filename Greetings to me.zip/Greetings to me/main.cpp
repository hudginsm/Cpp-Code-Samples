#include <iostream>
#include <string>
using namespace std;

int main()
{
    string x;
    int y = 0;

    cout << "Enter Name " << endl;
    cin >> x;
    if (x == "Marcus")
        cout << "You're amazing!" << endl;
    else
        cout << "You're not Marcus!" << endl;

    cout << "Enter Age" << endl;
    cin >> y;
    if (y != 22)
        cout << "You aren't the right age!" << endl;
    return 0;
}
