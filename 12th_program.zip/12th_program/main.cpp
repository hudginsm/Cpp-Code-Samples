#include <iostream>

using namespace std;

int main()
{
   int age = 21;

   switch(age)
   {
   case 16:
    cout << "hey you can drive" << endl;
    break;
   case 18:
    cout << "go buy lotto" << endl;
    break;
   case 21:
    cout << "go buy the beer" << endl;
    break;
   default:
    cout << "sorry you don't get anything." << endl;
   }
}
