#include <iostream>
using namespace std;

int main()
{
   for(int x = 5; x < 50; x+=5)
   {
       cout << x << endl;
   }
}
