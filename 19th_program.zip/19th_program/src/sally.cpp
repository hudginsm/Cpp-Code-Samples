#include "sally.h"
#include <iostream>
using namespace std;

Sally::Sally()
{
    cout << "i am the constructor!"<< endl;
}

Sally::~Sally()4
{
    cout << "i am the deconstuctor" << endl;
}
