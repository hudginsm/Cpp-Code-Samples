#include <iostream>
#include "sally.h"
using namespace std;

int main()
{
    Sally so;
    cout << "omg wtf is this on my shoe?"<< endl;
}
