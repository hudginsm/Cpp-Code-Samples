#include <iostream>
#include "birthday.h"
#include "people.h"
using namespace std;

int main()
{
    Birthday birthObj(12, 28, 1996);
    People buckyRoberts("bucky the king", birthObj);

    buckyRoberts.printInfo();
}
