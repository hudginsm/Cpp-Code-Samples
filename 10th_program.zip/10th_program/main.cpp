#include <iostream>
#include <cmath>
using namespace std;

int main()
{
   float a;

    return 0;
}
