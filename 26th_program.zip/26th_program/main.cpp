#include <iostream>
using namespace std;

class Enemy
{
public:
    void setAttackPower(int a)
    {
        attackPower = a;
    }
protected:
    int attackPower;
};

class Ninja: public Enemy
{
public:
    void attack()
    {
        cout << "I am a Ninja, NINJA CHOP! - " << attackPower << endl;
    }
};

class Monster: public Enemy
{
public:
    void attack()
    {
        cout << "Monster must EAT you! - " << attackPower << endl;
    }
};

int main()
{
    Ninja n;
    Monster m;
    Enemy *enemy1 = &n;
    Enemy *enemy2 = &m;
    enemy1->setAttackPower(33);
    enemy2->setAttackPower(99);
    n.attack();
    m.attack();
}
