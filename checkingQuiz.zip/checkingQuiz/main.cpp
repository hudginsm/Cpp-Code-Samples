#include <iostream>

using namespace std;

int main()
{
    int intx = 5;
    int inty;

    if(intx < 10)
        inty = 0;
    else if (intx < 20)
        inty = 1;
    else if (intx < 30)
        inty = 2;
    else if (intx < 40)
        inty = 3;
    cout << inty << endl;
}
