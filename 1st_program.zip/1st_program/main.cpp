#include <iostream>

using namespace std;

int main()
{
    int a;
    int b;
    int sum;

    cout << "Enter a number. \n";
    cin >> a;

    cout << "Enter another number. \n";
    cin >> b;

    sum = a + b;
    cout << "The sum of the two numbers is... \n";
    cout<< sum << endl;

    return 0;
}
