#include <iostream>
#include "sally.h"
using namespace std;

int main()
{
    Sally so(3,87);
    so.print();
}
