#include <iostream>

using namespace std;

int main()
{
    int x = 1;
    float number;
    float total = 0;

    while(x <= 20)
    {
       cout << "Enter your number, please" << endl;
       cin >> number;
       total = total + number;
        x++;
    }

    cout << "Your total is " << total << endl;

    return 0;
}
