#include <iostream>

using namespace std;

int main()
{
    int x;
    int y;

    cout << "Is.... (enter number) \n";
    cin >> x;

    cout << "less than...(enter number)\n";
    cin >> y;

    if (x<y)
        {
            cout << "Yes!!!";
        }
    if (x>=y)
        {
            cout << "No!!!";
        }

    return 0;
}
